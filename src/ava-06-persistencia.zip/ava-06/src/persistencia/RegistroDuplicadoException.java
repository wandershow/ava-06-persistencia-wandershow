package persistencia;

public class RegistroDuplicadoException extends RuntimeException {

}
