package modelo;

import java.time.LocalDate;

import cobaia.Genero;

public class Professor extends AbstractModel {

	public enum Formacao{
		Graduado, Mestrado, Doutorado, PHd;
	}

	
	private Integer id = null;
	private String nome;
	private LocalDate dataNascimento;
	private Formacao formacao;
	private Genero genero;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public LocalDate getDataNascimento() {
		return dataNascimento;
	}

	public void setDataNascimento(LocalDate dataNascimento) {
		this.dataNascimento = dataNascimento;
	}

	public Formacao getFormacao() {
		return formacao;
	}

	public void setFormacao(Formacao formacao) {
		this.formacao = formacao;
	}

	public Genero getGenero() {
		return genero;
	}

	public void setGenero(Genero genero) {
		this.genero = genero;
	}

	@Override
	public String toString() {
		return "Professor [id=" + id + ", nome=" + nome + ", dataNascimento=" + dataNascimento + ", formacao="
				+ formacao + ", genero=" + genero + "]";
	}

	

	
}
