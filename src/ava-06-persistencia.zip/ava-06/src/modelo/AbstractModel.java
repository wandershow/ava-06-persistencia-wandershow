package modelo;

import java.time.LocalDate;

import cobaia.Genero;

public abstract class AbstractModel {
			
	abstract Integer getId();
	
	abstract void setId(Integer id);
	
	abstract String getNome();
	
	abstract void setNome(String nome);
	
	abstract LocalDate getDataNascimento();
	
	abstract void setDataNascimento(LocalDate dataNascimento);
	
	abstract Genero getGenero();
	
	abstract void setGenero(Genero genero);

}
